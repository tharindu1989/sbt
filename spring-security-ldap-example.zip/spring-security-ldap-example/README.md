# Spring Security in a Spring Boot App using LDAP

LDAP Details
- Username: ben
- Password: benspassword