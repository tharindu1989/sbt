# spring-boot-angular6-maven-project
Build and package spring boot and angular6 into a deployable war file
